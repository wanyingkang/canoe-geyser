// C/C++

namespace Globals {

const char* search_paths = ".";

const char* banner = "\
######################################################\n\
##              APPLICATION STARTS                  ##\n\
######################################################";

int my_rank;
int nranks;

} // namespace Globals
